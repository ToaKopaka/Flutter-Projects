package com.example.toDoPractice

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
